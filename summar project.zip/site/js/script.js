// ===== Mobile nav toggle =====
(function(){
  const toggle = document.getElementById('nav-toggle');
  const links = document.getElementById('nav-links');
  if(toggle && links){
    toggle.addEventListener('click', function(){
      links.classList.toggle('open');
    });
  }
})();

// ===== Contact form (front-end only) =====
(function(){
  const form = document.getElementById('contact-form');
  const note = document.getElementById('form-note');
  if(!form) return;
  form.addEventListener('submit', function(e){
    e.preventDefault();
    note.textContent = 'Message captured locally — connect this form to your backend or an email service to send it.';
    note.className = 'form-note ok';
    form.reset();
  });
})();

// ===== Detection demo (simulated) =====
(function(){
  const canvas = document.getElementById('stage');
  if(!canvas) return;
  const ctx = canvas.getContext('2d');
  const fileInput = document.getElementById('file-input');
  const fileLabel = document.getElementById('file-label');
  const runBtn = document.getElementById('run-btn');
  const resultLine = document.getElementById('result-line');
  let img = null;
  let lastRect = null;

  function drawBlank(){
    ctx.fillStyle = '#0F1114';
    ctx.fillRect(0,0,canvas.width,canvas.height);
    ctx.strokeStyle = '#2A2E33';
    ctx.setLineDash([6,6]);
    ctx.strokeRect(20,20,canvas.width-40,canvas.height-40);
    ctx.setLineDash([]);
    ctx.fillStyle = '#5C6068';
    ctx.font = '13px Inter, sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText('No frame loaded', canvas.width/2, canvas.height/2);
  }
  drawBlank();

  function drawImageFitted(image){
    ctx.fillStyle = '#0F1114';
    ctx.fillRect(0,0,canvas.width,canvas.height);
    const scale = Math.min(canvas.width/image.width, canvas.height/image.height);
    const w = image.width*scale, h = image.height*scale;
    const x = (canvas.width-w)/2, y = (canvas.height-h)/2;
    ctx.drawImage(image, x, y, w, h);
    return {x,y,w,h};
  }

  fileInput.addEventListener('change', function(e){
    const file = e.target.files[0];
    if(!file) return;
    fileLabel.textContent = file.name;
    const reader = new FileReader();
    reader.onload = function(ev){
      img = new Image();
      img.onload = function(){
        lastRect = drawImageFitted(img);
        resultLine.textContent = 'Frame loaded — ready to run.';
        resultLine.className = 'result-line';
      };
      img.src = ev.target.result;
    };
    reader.readAsDataURL(file);
  });

  runBtn.addEventListener('click', function(){
    if(!img || !lastRect){
      resultLine.textContent = 'Choose an image first.';
      resultLine.className = 'result-line warn';
      return;
    }
    drawImageFitted(img);
    resultLine.textContent = 'Scanning head region…';
    resultLine.className = 'result-line';

    const r = lastRect;
    const boxSize = Math.max(40, Math.min(r.w, r.h) * 0.32);
    const bx = r.x + r.w/2 - boxSize/2;
    const by = r.y + r.h*0.12;

    setTimeout(function(){
      const isHelmet = Math.random() > 0.45;
      const color = isHelmet ? '#4CD787' : '#FF5A1F';
      const label = isHelmet ? 'HELMET · ' : 'NO HELMET · ';
      const conf = (0.84 + Math.random()*0.14).toFixed(2);

      ctx.strokeStyle = color;
      ctx.lineWidth = 2.5;
      ctx.strokeRect(bx, by, boxSize, boxSize);

      ctx.font = '600 12px "JetBrains Mono", monospace';
      const text = label + conf;
      const tw = ctx.measureText(text).width + 12;
      ctx.fillStyle = color;
      ctx.fillRect(bx, by-20, tw, 18);
      ctx.fillStyle = '#14161A';
      ctx.fillText(text, bx+6, by-6);

      resultLine.textContent = (isHelmet ? '✓ ' : '⚠ ') + text;
      resultLine.className = 'result-line ' + (isHelmet ? 'ok' : 'warn');
    }, 500);
  });
})();
